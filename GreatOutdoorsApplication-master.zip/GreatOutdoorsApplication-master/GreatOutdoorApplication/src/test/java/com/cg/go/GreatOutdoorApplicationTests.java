package com.cg.go;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreatOutdoorApplicationTests {
@Test
void contextLoads() {
GreatOutdoorApplication.main(new String[] {});
}
}



