package com.cg.go.exception;

public class GrowthReportException extends Exception {

	private static final long serialVersionUID = 1L;

	public GrowthReportException(String message) {

		super(message);
	}
}
