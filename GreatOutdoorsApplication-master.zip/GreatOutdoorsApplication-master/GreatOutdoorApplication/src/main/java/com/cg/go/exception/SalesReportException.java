package com.cg.go.exception;

public class SalesReportException extends Exception {

	private static final long serialVersionUID = 1L;

	public SalesReportException(String message) {
		super(message);
	}
}
